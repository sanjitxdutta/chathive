# chathive
ChatHive — A real-time, room-based chat app where users can join or create rooms and exchange messages instantly. Built with WebSockets for seamless communication.
